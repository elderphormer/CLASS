﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nums240083
{
    public class Numeros
    {
        private Num33Zero3[] m_numeros;
        private int m_qtdNums;

        public Numeros(int capacidade)
        {
            m_numeros = new Num33Zero3[capacidade];
            m_qtdNums = 0;
        }

        public int qtdNums
        {
            get { return m_qtdNums; }
        }

        public Num33Zero3 GetNumero(int index)
        {
            if (index >= 0 && index < m_qtdNums)
                return m_numeros[index];
            return null;
        }

        public bool Existe(int num)
        {
            for (int i = 0; i < m_qtdNums; i++)
            {
                if (m_numeros[i].valor == num)
                    return true;
            }
            return false;
        }

        public bool Inserir(Num33Zero3 num)
        {
            if (m_qtdNums >= m_numeros.Length)
                return false;

            m_numeros[m_qtdNums] = num;
            m_qtdNums++;
            return true;
        }

        public Num33Zero3 Menor()
        {
            if (m_qtdNums == 0) return null;

            Num33Zero3 menor = m_numeros[0];

            for (int i = 1; i < m_qtdNums; i++)
            {
                if (m_numeros[i].valor < menor.valor)
                    menor = m_numeros[i];
            }

            return menor;
        }

        public int Somatorio()
        {
            int soma = 0;

            for (int i = 0; i < m_qtdNums; i++)
            {
                soma += m_numeros[i].valor;
            }

            return soma;
        }

        public string Listar()
        {
            string res = "";

            for (int i = 0; i < m_qtdNums; i++)
            {
                res += m_numeros[i].valor + " ";
            }

            return res;
        }
        public bool Verifynum(int numero)
        {
            for( int i=0; i <m_qtdNums; i++)
                {
                if (m_numeros[i].valor)
            
        }
    }
}


