﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nums240083
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
            private Numeros lista;

        

        private void btnInserir_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero.Text, out int num))
            {
                MessageBox.Show("Valor inválido");
                return;
            }

            if (lista.Existe(num))
            {
                MessageBox.Show("Número repetido!");
                return;
            }

            try
            {
                Num33Zero3 obj = new Num33Zero3(num);

                if (!lista.Inserir(obj))
                {
                    MessageBox.Show("Array cheio!");
                    return;
                }

                lstb_insc.Items.Add(num + ", 33-Zero-3");
            }
            catch
            {
                lstb_insc.Items.Add(num + ", NÃO 33-Zero-3");
            }
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            lista = new Numeros(123); 
        }
    }
    }

